import os

for files in os.listdir("./frames"):
  print(files)