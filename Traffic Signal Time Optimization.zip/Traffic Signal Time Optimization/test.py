import cv2
import numpy as np
from ultralytics import YOLO
import os
from PIL import Image
import polars as pl
import csv

model = YOLO("yolov8x.pt")

# traffic_lane_data = pl.DataFrame()
with open("traffic_data.csv", mode="w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["framecount", "lane1", "lane2", "total"])
    for files in os.listdir("./frames"):
        path = "C:/Users/Asus/OneDrive/Desktop/Traffic Signal Time Optimization/frames/" + files
        frame = cv2.imread(path)
        results = model(frame)
        
        lane1 = np.array([(399, 435), (847, 437), (845, 417), (769, 376), (717, 347), (641, 291), (497, 289), (495, 311), (431, 343)])
        lane2 = np.array([(402, 423), (431, 351), (500, 317), (495, 283), (319, 269), (33, 437)])

        lane1_count = 0
        lane2_count = 0
        total_count = 0
        vehicle_classes = ["car", "truck", "bus", "motorcycle"]

        for r in results:
            for box in r.boxes:
                cls = int(box.cls[0])
                label = model.names[cls]

                if label in vehicle_classes :
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    cx = int((x1 + x2) / 2)
                    cy = int((y1 + y2) / 2)
                    
                    if cv2.pointPolygonTest(lane1, (cx, cy), False) >= 0:
                        lane1_count += 1
                        total_count += 1

                    elif cv2.pointPolygonTest(lane2, (cx, cy), False) >= 0:
                        lane2_count += 1
                        total_count += 1
        print("for",files)
        print("Lane1:", lane1_count)
        print("Lane2:", lane2_count)
        framecount = files.replace(".jpg","")
        writer.writerow([framecount, lane1_count, lane2_count, total_count])