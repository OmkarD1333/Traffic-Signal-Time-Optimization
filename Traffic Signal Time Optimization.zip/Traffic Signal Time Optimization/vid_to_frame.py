import cv2
import os


video_path = "demo_1.mp4"
output_folder = "frames"
os.makedirs(output_folder, exist_ok=True)

cap = cv2.VideoCapture(video_path)

fps = cap.get(cv2.CAP_PROP_FPS)
interval = int(fps * 1)   # 1 seconds interval

frame_count = 0
saved_count = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    if frame_count % interval == 0:
        cv2.imwrite(f"{output_folder}/frame_{saved_count}.jpg", frame)
        saved_count += 1

    frame_count += 1

cap.release()
print("Frames saved every 1 seconds ✅")