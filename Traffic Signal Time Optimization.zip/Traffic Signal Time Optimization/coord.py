import cv2
print("OpenCV Version:", cv2.__version__)
points = []

def mouse_callback(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        print(f"Clicked at: ({x}, {y})")
        points.append((x, y))

        # Draw point on image
        cv2.circle(frame, (x, y), 5, (0, 0, 255), -1)
        cv2.imshow("Frame", frame)

# Load one frame
frame = cv2.imread("frames/frame_0.jpg")

if frame is None:
    print("Image not found. Check path!")
    exit()
    
cv2.imshow("Frame", frame)
cv2.setMouseCallback("Frame", mouse_callback)

cv2.waitKey(0)
cv2.destroyAllWindows()

print("Selected Points:", points)
