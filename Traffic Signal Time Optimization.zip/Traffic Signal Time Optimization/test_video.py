import cv2
import numpy as np
from ultralytics import YOLO

model = YOLO("yolov8s.pt")

cap = cv2.VideoCapture("traffic_video.mp4")

fps = cap.get(cv2.CAP_PROP_FPS)
interval = int(fps * 1)

results = model(cap)

lane1 = np.array([(399, 435), (847, 437), (845, 417), (769, 376), (717, 347), (641, 291), (497, 289), (495, 311), (431, 343)])
lane2 = np.array([(402, 423), (431, 351), (500, 317), (495, 283), (319, 269), (33, 437)])

vehicle_classes = ["car", "truck", "bus", "motorcycle"]

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame)

    lane1_count = 0
    lane2_count = 0

    for r in results:
        for box in r.boxes:
            cls = int(box.cls[0])
            label = model.names[cls]

            if label in vehicle_classes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])

                cx = int((x1 + x2) / 2)
                cy = y2

                if cv2.pointPolygonTest(lane1, (cx, cy), False) >= 0:
                    lane1_count += 1
                elif cv2.pointPolygonTest(lane2, (cx, cy), False) >= 0:
                    lane2_count += 1

    print("Lane1:", lane1_count, "Lane2:", lane2_count)

cap.release()
